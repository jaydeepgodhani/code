package iiitb_java;
import java.util.*;
class setTeam
{
	int rank;
	String name;
	void initializeTeam(int a)
	{
		setTeam temp1,temp2;
		Scanner sc = new Scanner(System.in);
		ArrayList<setTeam> t = new ArrayList<setTeam>();
		for(int i=0;i<a;i++)
		{
			setTeam st=new setTeam();
			System.out.println("Enter int and string for your team");
			st.rank= sc.nextInt();
			st.name=sc.nextLine();
			t.add(st);
		}
		while(t.size()!=1)
		{
			temp1=t.get(0);
			temp2=t.get(1);
			if(temp1.rank>temp2.rank)
			{
				t.add(temp1);
				t.remove(0);
				t.remove(1);
				System.out.println("winner of this round "+temp1.name+"("+temp1.rank+")");
			}
			else
			{
				t.add(temp2);
				t.remove(0);
				t.remove(1);
				System.out.println("winner of this round "+temp2.name+"("+temp2.rank+")");
			}
		}
		temp1=t.get(0);
		System.out.println("winner of this GAME is "+temp1.name);
		//Testing purpose
		/*for(int i=0;i<a;i++)
		{
			temp=t.get(i);
			System.out.println("haha "+temp.rank+" hoho "+temp.name);
		}*/
	}
}
public class initiateGame
{
	public static void main(String[] args)
	{
		System.out.println("How many teams you want?");
		Scanner sc = new Scanner(System.in);
		int teams = sc.nextInt();
		//System.out.println("your teams are "+teams);
		if(teams%2==0)
		{
			setTeam st = new setTeam();
			st.initializeTeam(teams);
		}
		else
		{
			System.out.println("Enter multiple of 2 number");
		}
	}
}