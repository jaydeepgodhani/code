package iiitb_java;
import java.util.*;
class Bakery
{
	String index, order, quantity,whole;
	ArrayList<String>bk=new ArrayList<String>();
	ArrayList<String> get_item()
	{
		return bk;
	}
	void set_item(int a,String b,String c)
	{
		index = Integer.toString(a+1);
		order = b;
		quantity = c;
		whole = index+" "+order+" "+quantity;
		bk.add(whole);
	}
}
class Dairy
{
	String index, order, quantity,whole;
	ArrayList<String>bk=new ArrayList<String>();
	ArrayList<String> get_item()
	{
		return bk;
	}
	void set_item(int a,String b,String c)
	{
		index = Integer.toString(a+1);
		order = b;
		quantity = c;
		whole = index+" "+order+" "+quantity;
		bk.add(whole);
	}
}
public class Store
{
	int i;
	ArrayList<String> b_items = new ArrayList<String>(Arrays.asList("bread","cakes","muffins"));
	ArrayList<String> d_items = new ArrayList<String>(Arrays.asList("milk","butter"));
	void createObj(int a,int b,ArrayList<String> str)
	{
		Bakery b1[]=new Bakery[a];
		Dairy d1[]=new Dairy[b];
		int x=0,y=0;
		for(i=0;i<a;i++)b1[i]=new Bakery();
		for(i=0;i<b;i++)d1[i]=new Dairy();
		for(String st : str)
		{
			String[] order= new String[2];
			order=st.split("\\s+");
			//System.out.println(str.indexOf(st)+" "+order[0]+" "+order[1]);
			if(b_items.contains(order[0].toLowerCase()))
			{
				b1[(x++)%a].set_item(str.indexOf(st),order[0],order[1]);
			}
			else if(d_items.contains(order[0].toLowerCase()))
			{
				d1[(y++)%b].set_item(str.indexOf(st),order[0],order[1]);
			}
			else
			{
				System.out.println("We're not providing that item");
			}
		}
		for(i=0;i<a;i++)
		{
			ArrayList<String> temp=b1[i].get_item();
			System.out.println("Bakery "+(i+1));
			for(String tp1:temp)
			{
				System.out.println(tp1);
			}
			System.out.println();
		}
		for(i=0;i<b;i++)
		{
			ArrayList<String> temp=d1[i].get_item();
			System.out.println("Dairy "+(i+1));
			for(String tp1:temp)
			{
				System.out.println(tp1);
			}
			System.out.println();
		}
	}
}