package iiitb_java;
import java.util.*;
public class JavaLab2
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int a,b;
		String temp;
		ArrayList<String> str=new ArrayList<String>();
		a = sc.nextInt();
		b = sc.nextInt();
		sc.nextLine();
		temp = sc.nextLine();
		do
		{
			str.add(temp);
			temp=sc.nextLine();
		}while(!(temp.toLowerCase()).equals("end"));
		Store st=new Store();
		st.createObj(a,b,str);
	}
}
