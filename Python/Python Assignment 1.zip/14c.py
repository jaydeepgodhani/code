import sys
a=input('enter int ')
count=0
while(count<a):
    print 'Hello World!'
    count+=1
exit(0)