import math

#1.3
print 'Hello World!'

#1.4
var1,var2=5,7
var3 = var1+var2
print 'Sum of both variables is ',var3

#1.5
a,b=3,4
c=math.sqrt(a*a + b*b)
print 'Length of hypotenuse is ',c

#1.6
firstn,lastn = 'jaydeep','godhani'
fulln = firstn+' '+lastn
print 'Full name is ',fulln

#1.8
a=990
l=290
v=1100
total=a+l+v
each=total/3
print 'due amount of abhiraj,leon and vigyan is ',each-a,each-l,each-v