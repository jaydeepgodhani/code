import sys
a=input('enter int ')
if a<5:
    print 'infant'
elif 5<=a<18:
    print 'child'
else:
    print 'adult'