import sys
a=input('enter int ')
if a<18 :
    print 'child'
else:
    print 'adult'