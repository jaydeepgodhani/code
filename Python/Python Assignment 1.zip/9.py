import sys

c = sys.argv[1]
if c == 'y':
    print 'yes\nHello World!'
else:
    print 'Hello World!'